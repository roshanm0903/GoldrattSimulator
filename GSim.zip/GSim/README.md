# GoldrattSimulator
Custom version of Goldratt Simulator used to study manufacturing operations. 
The factory can be setup using the config excel file.
